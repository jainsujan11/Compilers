// small test file
int main(){
    int a = 10;
    return 0;
}
